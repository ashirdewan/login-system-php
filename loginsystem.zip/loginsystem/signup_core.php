<?php
require_once("dbConnection.php");
$fname=$_REQUEST["fname"];
$lname=$_REQUEST["lname"];
$email=$_REQUEST["email"];
$password=md5(sha1($_REQUEST["password"]));
$username=$_REQUEST["username"];
$token=md5(sha1($username.$password));

$myQuery="INSERT INTO `information`(`fname`,`lname`,`email`,`passwords`,`username`,`token`) VALUES ('$fname','$lname','$email','$password','$username','$token');";
$runQuery=mysqli_query($dbconnection,$myQuery);
if($runQuery==true)
{
    header("location:login.php?message=Registration Successful.");
}
else{
    header("location:login.php?message=Registration Failed.");
}

?>