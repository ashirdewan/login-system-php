<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<form action="signup_core.php" method="post">

<input type="text" name="fname" id="" placeholder="First Name"><br><br>
<input type="text" name="lname" id="" placeholder="Last Name"><br><br>
<input type="email" name="email" id="" placeholder="Email Address"><br><br>
<input type="password" name="password" id="" placeholder="Password"><br><br>
<input type="text" name="username" id="" placeholder="User Name"><br><br>
<input type="submit" value="Register" name="registerBtn">

</form>

</body>
</html>