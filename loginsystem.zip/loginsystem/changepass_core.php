<?php

require_once("dbConnection.php");


if(!empty($_REQUEST["oldPwd"]) && !empty($_REQUEST["newPwd"]) && !empty($_REQUEST["rnewPwd"])){
   $oldPwd = md5(sha1($_REQUEST["oldPwd"]));
   $newPwd = md5(sha1($_REQUEST["newPwd"]));
   $rnewPwd = md5(sha1($_REQUEST["rnewPwd"]));

   $token=$_COOKIE["hsmfbcnsdmc"];
   
   

   $myQuery1 ="SELECT * FROM information WHERE token='$token'; ";
   $runQuery1=mysqli_query($dbconnection,$myQuery1);
   
    $rowCount1=mysqli_num_rows($runQuery1);

    if($rowCount1==1){
        while($myData1=mysqli_fetch_array($runQuery1)){
            $dbuname=$myData1["username"];
            $dbPwd=$myData1["passwords"];
        }
      
    }
    $updatedtoken=md5(sha1($dbuname.$newPwd));
    if($oldPwd==$dbPwd && $newPwd==$rnewPwd){
        $myQuery2 ="UPDATE `information` SET `passwords`='$newPwd',`token`='$updatedtoken' WHERE token='$token';";
        $runQuery2=mysqli_query($dbconnection,$myQuery2);
        require_once("logout_core.php");   
        header("location:login.php?message=Password Changed.");
           
    }
    else{
        header("location:changepass.php?message=Password mismatch.");
      }
    


}
else{
    header("location:changepass.php?message=Fill up all the box.");
}

?>
