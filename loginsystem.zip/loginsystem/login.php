<?php
if(isset($_COOKIE["hsmfbcnsdmc"])){
    header("location: profile.php?message=You are trying to do some invalid operation without logout you can't go to login page.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
</head>
<body>
    <form action="login_core.php" method="post">

    <input type="text" name="uname" id="" placeholder="Username"><br><br>
    <input type="password" name="pwd" id="" placeholder="Password"><br><br>
    <input type="submit" value="Login" name="loginBtn"><br>
    
    </form>
    <br>
    Are you new? Sign Up hare
    <button><a href="signup.php">Sign Up</a></button><br>
    <?php
if(isset($_REQUEST["message"])){
    $m = $_REQUEST["message"];
    ?>
<h3 style='color:green' ><?php echo $m?></h3>

    <?php
}

?>


    

    
</body>
</html>