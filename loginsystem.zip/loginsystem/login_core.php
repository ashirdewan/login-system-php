<?php

require_once("dbConnection.php");


if(!empty($_REQUEST["uname"]) && !empty($_REQUEST["pwd"])){
   $provideUname = $_REQUEST["uname"];
   $providePwd = md5(sha1($_REQUEST["pwd"]));
   $token=md5(sha1($provideUname.$providePwd));
   
   

   $myQuery ="SELECT * FROM information WHERE token='$token'; ";
   $runQuery=mysqli_query($dbconnection,$myQuery);
   
    $rowCount=mysqli_num_rows($runQuery);

    if($rowCount==1){
      setcookie('hsmfbcnsdmc',$token,time()+86400);
      header("location:profile.php?token=$token");
      
    }
    else{
      header("location:login.php?message=Incorrect username or password.");
    }

  }
else{
  header("location:login.php?message=Please Provide Username and Password both.");
}

?>
