<?php
if(isset($_REQUEST["message"])){
    $m = $_REQUEST["message"];
    ?>
<h3 style='color:green' ><?php echo $m?></h3>
    <?php
}
?>
<?php

if(isset($_REQUEST["token"])){
 $token = $_REQUEST["token"];


require_once("dbConnection.php");
$myQuery="SELECT * FROM information WHERE token='$token'";
$runQuery=mysqli_query($dbconnection,$myQuery);

while($myData=mysqli_fetch_array($runQuery)){
    echo "Welcome ".$myData["fname"];
}
}

?>
<br>
<form action="logout_core.php" method="post">
<input type="submit" value="Logout" name="logoutBtn">
</form>

<form action="changepass.php" method="post">
<input type="submit" value="Change Password" name="cngPass">
</form>

