
<form action="changepass_core.php" method="post">

<input type="text" name="oldPwd" id="" placeholder="Old Password"><br><br>
<input type="text" name="newPwd" id="" placeholder="New Password"><br><br>
<input type="text" name="rnewPwd" id="" placeholder="Re Enter New Password"><br><br>
<input type="submit" value="Confirm" name="cnfrmBtn">
<?php
if(isset($_REQUEST["message"])){
    $m = $_REQUEST["message"];
    ?>
<h3 style='color:green' ><?php echo $m?></h3>
    <?php
}

?>

</form>
