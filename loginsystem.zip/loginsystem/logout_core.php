<?php
 setcookie('hsmfbcnsdmc','',time()-86400*2);
 header("location:login.php");
?>